
export enum TabType {
  MAIN = 'MAIN',
  ABOUT = 'ABOUT',
  PRIVACY = 'PRIVACY'
}

export type Language = 'en' | 'ar';

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
